﻿namespace Common
{
    public static class Const
    {
        public const string ExchangeName = "AMU.EXCHANGE.TOPIC";
    }
}