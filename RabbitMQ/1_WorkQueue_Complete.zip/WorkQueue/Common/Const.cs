﻿namespace Common
{
    public static class Const
    {
        public const string ExchangeName = "AMU.EXCHANGE";
        public const string RoutingKey = "AMU.EXAMPLE1.TASK";
        public const string QueueName = "AMU.EXAMPLE1.WORKER_QUEUE";
        public const int MessageCount = 10;
    }
}